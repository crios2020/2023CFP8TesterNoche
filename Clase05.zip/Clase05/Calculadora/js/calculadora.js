function sumar(){
    console.log(document.getElementById("nro1").value)
    if(
        document.getElementById("nro1").value!='' &&
        document.getElementById("nro2").value!=''){
            nro1=parseFloat(document.getElementById("nro1").value)
            nro2=parseFloat(document.getElementById("nro2").value)
            resultado=nro1+nro2
            document.getElementById("resultado").value=resultado
        }else{
            document.getElementById("resultado").value="Error de parámetros"
        }
}
function restar(){
    if(
        document.getElementById("nro1").value!='' &&
        document.getElementById("nro2").value!=''){
            nro1=parseFloat(document.getElementById("nro1").value)
            nro2=parseFloat(document.getElementById("nro2").value)
            resultado=nro1-nro2
            document.getElementById("resultado").value=resultado
    }else{
        document.getElementById("resultado").value="Error de parámetros"
    }
}
function multiplicar(){
    if(
        document.getElementById("nro1").value!='' &&
        document.getElementById("nro2").value!=''){
            nro1=parseFloat(document.getElementById("nro1").value)
            nro2=parseFloat(document.getElementById("nro2").value)
            resultado=nro1*nro2
            document.getElementById("resultado").value=resultado
    }else{
        document.getElementById("resultado").value="Error de parámetros"
    }
}
function dividir(){
    if(
        document.getElementById("nro1").value!='' &&
        document.getElementById("nro2").value!=''){
            nro1=parseFloat(document.getElementById("nro1").value)
            nro2=parseFloat(document.getElementById("nro2").value)
            if(nro2!=0){
                resultado=nro1/nro2
                document.getElementById("resultado").value=resultado
            } else {
                document.getElementById("resultado").value="error /0"
            }
    }else{
        document.getElementById("resultado").value="Error de parámetros"
    }
}