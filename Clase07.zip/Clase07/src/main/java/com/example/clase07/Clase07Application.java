package com.example.clase07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase07Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase07Application.class, args);
	}

}
