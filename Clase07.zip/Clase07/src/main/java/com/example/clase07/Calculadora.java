package com.example.clase07;

public class Calculadora {
    public static double sumar(double nro1, double nro2){
        return 0;
    }
    public static double restar(double nro1, double nro2){
        return 0;
    }
    public static double multiplicar(double nro1, double nro2){
        return 0;
    }
    public static double dividir(double nro1, double nro2){
        return 0;
    }
}
