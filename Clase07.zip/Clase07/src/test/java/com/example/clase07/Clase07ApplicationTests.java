package com.example.clase07;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase07ApplicationTests {

	@Test
	void prueba1(){
		assertEquals(true, true);	//green
	}

	@Test
	void prueba2(){
		//assertEquals(true, false);	//red
	}

	@Test
	void prueba3(){
		assertEquals(2+2, 4);	//green
	}

	@Test
	void prueba4(){
		//assertEquals(2+2, 5);	//red
	}

	@Test
	void sumar1(){
		assertEquals(Calculadora.sumar(2,2), 4);
	}

	@Test
	void sumar2(){
		assertEquals(Calculadora.sumar(5, -4), 1);
	}

	@Test
	void sumar3(){
		//prueba erronea
		//assertEquals(Calculadora.sumar(2,2), 5);
	}

}
