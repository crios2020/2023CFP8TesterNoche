package com.example.clase07;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase07ApplicationTests {

	private Calculadora calculadora=new Calculadora();

	@Test
	public void suma_dos_parametros(){
		assertEquals(calculadora.sumar(10, 10), 20);
	}

	@Test
	public void suma_no_enteros01(){
		assertEquals(calculadora.sumar(10,10.0), 20);
	}

	@Test
	public void suma_no_enteros02(){
		assertEquals(calculadora.sumar(3.5,5.5), 9);
	}

	@Test
	public void suma_no_enteros03(){
		assertEquals(calculadora.sumar(4.1,4), 8.1);
	}

	@Test
	public void suma_no_enteros04(){
		assertEquals(calculadora.sumar(4.1,5.6), 9.7);
	}

	@Test
	public void suma_neutros01(){
		assertEquals(calculadora.sumar(10,0), 10);
	}

	@Test
	public void suma_neutros02(){
		assertEquals(calculadora.sumar(0,10), 10);
	}

	@Test
	public void suma_neutros03(){
		assertEquals(calculadora.sumar(0,0), 0);
	}

	@Test
	public void suma_negativos01(){
		assertEquals(calculadora.sumar(-10,-10), -20);
	}

	@Test
	public void suma_negativos02(){
		assertEquals(calculadora.sumar(-5,10), 5);
	}

	@Test
	public void suma_negativos03(){
		assertEquals(calculadora.sumar(10,-50), -40);
	}

	@Test
	public void suma_negativos04(){
		assertEquals(calculadora.sumar(-10,-0), -10);
	}

	@Test
	public void suma_desbordamiento01(){
		assertEquals(calculadora.sumar(2000000000,2000000000), 4000000000L);
	}

	@Test
	public void suma_desbordamiento02(){
		assertEquals(calculadora.sumar(-2000000000,-2000000000), -4000000000L);
	}

}
