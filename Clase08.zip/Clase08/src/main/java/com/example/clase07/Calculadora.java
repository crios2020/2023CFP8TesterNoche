package com.example.clase07;

/**
 * Programa calculadora
 */
public class Calculadora {

    /**
     * función sumar, suma los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return retorna la suma de los dos parámetros de entrada
     */
    public static double sumar(double nro1, double nro2){
        //TODO sumar los parámetros de entrada
        return 0;
    }
        
    /**
     * función restar, resta los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return retorna la resta de los dos parámetros de entrada
     */
    public static double restar(double nro1, double nro2){
        //TODO restar los parámetros de entrada
        return 0;
    }
        
    /**
     * función multiplicar, multiplica los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return retorna la multiplicación de los dos parámetros de entrada
     */
    public static double multiplicar(double nro1, double nro2){
        //TODO multiplicar los parámetros de entrada
        return 0;
    }

        
    /**
     * función dividir, divide los parámetros de entrada
     * @param nro1 número 1
     * @param nro2 número 2
     * @return retorna la división de los dos parámetros de entrada
     */
    public static double dividir(double nro1, double nro2){
        //TODO dividir los parámetros de entrada
        return 0;
    }
}
